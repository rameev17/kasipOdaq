import Ticket from './Ticket'

export default Ticket