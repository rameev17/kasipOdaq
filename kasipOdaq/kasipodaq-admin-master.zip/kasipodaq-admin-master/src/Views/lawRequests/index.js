import LawRequests from './LawRequests'

export default LawRequests