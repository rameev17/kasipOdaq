import FrontPage from './FrontPage'

export default FrontPage