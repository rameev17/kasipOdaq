from unittest import TestCase


class TestEntity(TestCase):
    pass
