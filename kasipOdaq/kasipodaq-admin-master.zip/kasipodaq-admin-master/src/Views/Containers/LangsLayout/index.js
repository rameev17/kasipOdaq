import LangsLayout from './LangsLayout'

export default LangsLayout