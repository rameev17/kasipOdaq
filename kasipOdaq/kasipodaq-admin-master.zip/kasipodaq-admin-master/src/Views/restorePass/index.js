import RestorePass from './RestorePass'

export default RestorePass