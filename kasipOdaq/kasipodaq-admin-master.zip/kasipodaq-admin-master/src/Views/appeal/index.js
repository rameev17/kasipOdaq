import YntymaqRequests from './YntymaqRequests'

export default YntymaqRequests