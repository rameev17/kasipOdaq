import kz from './kz.json';

export default { kz };