import News from './News'

export default News