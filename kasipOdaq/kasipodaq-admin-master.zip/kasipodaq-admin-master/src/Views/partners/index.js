import Partners from './Partners'

export default Partners