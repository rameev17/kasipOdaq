import CreateTicket from './CreateTicket'

export default CreateTicket