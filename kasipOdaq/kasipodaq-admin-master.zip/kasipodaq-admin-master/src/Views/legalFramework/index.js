import LegalFramework from './LegalFramework'

export default LegalFramework