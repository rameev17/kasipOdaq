import React from 'react'

class Eula extends React.Component{

    render(){

        return(
            <div className='eula-page'>
            Текст Пользовательского соглашения
        </div>
        )
    }
}

export default Eula