from django.apps import AppConfig


class UnionAppConfig(AppConfig):
    name = 'union_app'
