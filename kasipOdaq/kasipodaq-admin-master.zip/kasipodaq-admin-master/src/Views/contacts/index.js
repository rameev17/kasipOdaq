import Contacts from './Contacts'

export default Contacts