import BreadCrumbs from './BreadCrumbs';

export default BreadCrumbs;