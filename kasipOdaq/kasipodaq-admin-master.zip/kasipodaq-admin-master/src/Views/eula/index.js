import Eula from './Eula'

export default Eula