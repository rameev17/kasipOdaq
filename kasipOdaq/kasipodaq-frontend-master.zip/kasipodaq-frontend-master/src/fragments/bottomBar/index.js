import BottomBar from './BottomBar'

export default BottomBar