import Tribune from './Tribune'

export default Tribune