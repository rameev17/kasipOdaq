import {ModalChangeLang, ModalLogout, ModalChangePass} from './Modal'

export {ModalChangeLang, ModalLogout, ModalChangePass}